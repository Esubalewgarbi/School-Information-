package com.idb.model;

public class Classes {
    private int c_id;
    private String c_name;
    private int sess_id;

    public int getC_id() {
        return c_id;
    }

    public void setC_id(int c_id) {
        this.c_id = c_id;
    }

    public String getC_name() {
        return c_name;
    }

    public void setC_name(String c_name) {
        this.c_name = c_name;
    }

    public int getSess_id() {
        return sess_id;
    }

    public void setSess_id(int sess_id) {
        this.sess_id = sess_id;
    }

    
}
