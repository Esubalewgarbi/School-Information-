/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.idb.model;

/**
 *
 * @author SAIFUL
 */
public class Sessions {
    private int sess_id;
    private String sess_year;

    public int getSess_id() {
        return sess_id;
    }

    public void setSess_id(int sess_id) {
        this.sess_id = sess_id;
    }

    public String getSess_year() {
        return sess_year;
    }

    public void setSess_year(String sess_year) {
        this.sess_year = sess_year;
    }
    
    
}
